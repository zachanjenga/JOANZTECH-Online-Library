# JOANZTECH Online Library — Native Android Edition

This folder is a native Android/Gradle conversion of the original Flutter JOANZTECH Online Library project.

## Native stack
- Kotlin
- Android Gradle Plugin
- AndroidX + Material Components
- XML/programmatic Android Views (no Flutter runtime)
- Minimum Android API 23
- Target/compile API 35

## Included
- JOANZTECH Online Library branding and original supplied assets
- Login / account creation UI
- Library home screen
- Search
- 8 library categories
- Subscription screen (KSh 500 / Till 4615592)
- Profile screen
- PDF opening hook
- Contact/call action
- Original Firebase Cloud Functions, Firestore rules, Storage rules and indexes retained for backend integration

## Important backend note
The original Flutter project uses Firebase Authentication, Firestore, Firebase Storage and a Firebase Cloud Function for M-Pesa STK Push. The native conversion currently uses local/offline account/subscription state so the Android project remains independent of a Firebase project.

For production, connect the native screens to the existing Firebase backend. You will need a Firebase Android app configuration (`google-services.json`) and native Firebase SDK dependencies. The original `functions/` directory contains the M-Pesa Cloud Function.

The M-Pesa server secrets must remain on the server; do not place consumer keys, consumer secrets or passkeys inside the APK.

## Open in Android Studio
1. Open this folder as an existing Gradle project.
2. Allow Android Studio to install/sync the Android Gradle Plugin and dependencies.
3. Set an Android SDK with API 35 installed.
4. Build > Make Project.
5. Build > Generate Signed App Bundle / APK.

## Command line
From the project root, once Gradle/Android SDK are installed:

```bash
gradle assembleDebug
gradle assembleRelease
```

The release APK will be under:

`app/build/outputs/apk/release/app-release.apk`

## Package ID
`com.joanztech.onlinelibrary`

## Original project reference
The Flutter source is preserved in the uploaded source archive. This native project intentionally avoids requiring Flutter/Dart at runtime.
