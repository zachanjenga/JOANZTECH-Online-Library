package com.joanztech.onlinelibrary

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.joanztech.onlinelibrary.data.LibraryRepository
import com.joanztech.onlinelibrary.model.LibraryDocument

class MainActivity : ComponentActivity() {
    private val green = Color.rgb(7, 91, 42)
    private val gold = Color.rgb(212, 160, 23)
    private val navy = Color.rgb(16, 42, 92)
    private val light = Color.rgb(247, 249, 247)
    private lateinit var root: LinearLayout
    private val prefs by lazy { getSharedPreferences("joanztech", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLogin()
    }

    private fun base(): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(light)
        }
        return root
    }

    private fun scroll(content: View): ScrollView = ScrollView(this).apply {
        addView(content)
        setPadding(dp(16), dp(10), dp(16), dp(28))
    }

    private fun column(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
    }

    private fun text(value: String, size: Float = 16f, color: Int = Color.DKGRAY, bold: Boolean = false): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun logo(): ImageView = ImageView(this).apply {
        setImageResource(com.joanztech.onlinelibrary.R.drawable.joanztech_library_logo)
        adjustViewBounds = true
        scaleType = ImageView.ScaleType.CENTER_INSIDE
    }

    private fun button(label: String, onClick: () -> Unit): MaterialButton = MaterialButton(this).apply {
        text = label
        setOnClickListener { onClick() }
        isAllCaps = false
    }

    private fun field(hint: String, password: Boolean = false): TextInputLayout {
        val input = TextInputEditText(this).apply {
            textSize = 16f
            if (password) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        return TextInputLayout(this).apply {
            this.hint = hint
            addView(input)
            tag = input
            layoutParams = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) }
        }
    }

    private fun showLogin() {
        setContentView(base())
        val box = column()
        val l = logo().apply { layoutParams = LinearLayout.LayoutParams(dp(110), dp(110)).apply { gravity = Gravity.CENTER_HORIZONTAL } }
        box.addView(l)
        box.addView(text("READ • LEARN • GROW", 13f, green, true).apply { gravity = Gravity.CENTER })
        box.addView(space(10))
        box.addView(text("Welcome back", 28f, navy, true))
        val email = field("Email address")
        val password = field("Password", true)
        box.addView(email); box.addView(password)
        val login = button("LOGIN") {
            val e = (email.tag as TextInputEditText).text.toString().trim()
            val p = (password.tag as TextInputEditText).text.toString()
            if (e.isEmpty() || p.isEmpty()) toast("Email and password are required.") else {
                prefs.edit().putBoolean("loggedIn", true).putString("name", e.substringBefore('@')).putString("email", e).apply()
                showHome()
            }
        }
        box.addView(login)
        box.addView(button("CREATE ACCOUNT") { showRegister() })
        box.addView(button("Forgot password?") { toast("Password reset requires the Firebase backend in the production build.") })
        box.addView(text("Yearly subscription: KSh 500 • M-Pesa Till 4615592", 14f, Color.DKGRAY).apply { gravity = Gravity.CENTER })
        root.addView(scroll(box), LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun showRegister() {
        setContentView(base())
        val box = column()
        box.addView(logo().apply { layoutParams = LinearLayout.LayoutParams(dp(90), dp(90)).apply { gravity = Gravity.CENTER_HORIZONTAL } })
        box.addView(text("Create your account", 27f, navy, true))
        val name = field("Full name"); val phone = field("Phone number"); val email = field("Email address"); val pass = field("Password", true)
        listOf(name, phone, email, pass).forEach(box::addView)
        box.addView(button("CREATE ACCOUNT") {
            val n=(name.tag as TextInputEditText).text.toString().trim(); val p=(phone.tag as TextInputEditText).text.toString().trim(); val e=(email.tag as TextInputEditText).text.toString().trim(); val pw=(pass.tag as TextInputEditText).text.toString()
            if(n.isEmpty()||p.isEmpty()||e.isEmpty()||pw.isEmpty()) toast("Please complete all fields.") else { prefs.edit().putBoolean("loggedIn",true).putString("name",n).putString("phone",p).putString("email",e).apply(); showHome() }
        })
        box.addView(button("Already have an account? Login") { showLogin() })
        root.addView(scroll(box), LinearLayout.LayoutParams(-1,0,1f))
    }

    private fun showHome() {
        setContentView(base())
        val bar = LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL; setPadding(dp(10),dp(8),dp(10),dp(4)) }
        bar.addView(logo().apply { layoutParams=LinearLayout.LayoutParams(dp(55),dp(55)) })
        bar.addView(text("JOANZTECH ONLINE LIBRARY",18f,green,true).apply { layoutParams=LinearLayout.LayoutParams(0,-2,1f).apply{leftMargin=dp(8)} })
        val profile=ImageButton(this).apply{setImageResource(android.R.drawable.ic_menu_myplaces);setBackgroundColor(Color.TRANSPARENT);setOnClickListener{showProfile()}}
        bar.addView(profile)
        root.addView(bar)

        val content=column()
        val hero=MaterialCardView(this).apply { radius=dp(20).toFloat(); setCardBackgroundColor(green); setContentPadding(dp(16),dp(16),dp(16),dp(16)) }
        val heroRow=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
        val heroText=column(); heroText.addView(text("JOANZTECH ONLINE LIBRARY",22f,Color.WHITE,true)); heroText.addView(text("Your Knowledge. Your Future. Anytime, Anywhere.",14f,Color.WHITE)); heroText.addView(text("Yearly subscription: KSh 500",15f,gold,true)); heroRow.addView(heroText,LinearLayout.LayoutParams(0,-2,1f))
        heroRow.addView(ImageView(this).apply{setImageResource(R.drawable.ceo_zacharia);scaleType=ImageView.ScaleType.CENTER_CROP;layoutParams=LinearLayout.LayoutParams(dp(95),dp(115))})
        hero.addView(heroRow); content.addView(hero)
        content.addView(space(10))
        if(!prefs.getBoolean("subscribed",false)) content.addView(button("SUBSCRIBE FOR KSh 500") { showPayment() })
        val search=field("Search notes, past papers or topics..."); content.addView(search)
        content.addView(text("Library Categories",19f,navy,true))
        val chips=ChipGroup(this).apply{isSingleSelection=true;isSelectionRequired=false}
        LibraryRepository.categories.forEach{ c-> chips.addView(Chip(this).apply{text=c;setOnClickListener{renderDocs(content, search, c)}}) }
        content.addView(chips)
        val docsBox=column(); content.addView(docsBox)
        fun refresh(){
            val q=(search.tag as TextInputEditText).text.toString().trim().lowercase(); docsBox.removeAllViews(); LibraryRepository.all().filter{q.isEmpty()||("${it.title} ${it.description} ${it.category}").lowercase().contains(q)}.forEach{docsBox.addView(docCard(it))}
        }
        (search.tag as TextInputEditText).addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){refresh()};override fun afterTextChanged(e:android.text.Editable?){}})
        refresh()
        content.addView(contactCard())
        root.addView(scroll(content),LinearLayout.LayoutParams(-1,0,1f))
    }

    private fun renderDocs(content: LinearLayout, search: TextInputLayout, category: String){
        val container=content.getChildAt(content.childCount-2) as? LinearLayout ?: return
        container.removeAllViews()
        LibraryRepository.all().filter{it.category==category}.forEach{container.addView(docCard(it))}
    }

    private fun docCard(doc: LibraryDocument): View {
        return MaterialCardView(this).apply{
            radius=dp(14).toFloat(); setContentPadding(dp(14),dp(10),dp(14),dp(10)); layoutParams=LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(9)}
            val c=column(); c.addView(text(doc.title,18f,navy,true)); c.addView(text(doc.category,13f,green,true)); c.addView(text(doc.description,14f,Color.DKGRAY)); c.addView(button("READ / OPEN PDF"){if(prefs.getBoolean("subscribed",false)) openDocument(doc) else showPayment()}); addView(c)
        }
    }

    private fun openDocument(doc: LibraryDocument){
        if(doc.pdfUrl.isBlank()){toast("This sample resource has no PDF link yet. The production app can load authorized Firebase/Storage PDF links here.");return}
        try{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(doc.pdfUrl)))}catch(e:Exception){toast("Could not open the PDF link.")}
    }

    private fun showPayment(){
        setContentView(base()); val c=column(); c.addView(logo().apply{layoutParams=LinearLayout.LayoutParams(dp(90),dp(90)).apply{gravity=Gravity.CENTER_HORIZONTAL}}); c.addView(text("YEARLY SUBSCRIPTION",26f,navy,true)); c.addView(text("KSh 500",42f,gold,true)); c.addView(text("Pay through M-Pesa Till Number: 4615592",16f)); val phone=field("M-Pesa phone number"); c.addView(phone); c.addView(button("I HAVE PAID") { prefs.edit().putBoolean("subscribed",true).apply(); toast("Subscription marked active for this offline/native build."); showHome() }); c.addView(text("Production version: connect this screen to the existing Firebase Cloud Function/M-Pesa STK Push backend for automatic payment confirmation.",13f,Color.DKGRAY)); c.addView(button("BACK") { showHome() }); root.addView(scroll(c),LinearLayout.LayoutParams(-1,0,1f))
    }

    private fun showProfile(){
        setContentView(base()); val c=column(); c.addView(logo().apply{layoutParams=LinearLayout.LayoutParams(dp(90),dp(90)).apply{gravity=Gravity.CENTER_HORIZONTAL}}); c.addView(text(prefs.getString("name","Student") ?: "Student",24f,navy,true)); c.addView(text(prefs.getString("email","") ?: "",15f)); c.addView(text(if(prefs.getBoolean("subscribed",false)) "Subscription Active" else "Subscription Inactive",16f,if(prefs.getBoolean("subscribed",false))green:Color.DKGRAY,true)); c.addView(button("PAY / RENEW SUBSCRIPTION"){showPayment()}); c.addView(button("LOG OUT"){prefs.edit().clear().apply();showLogin()}); c.addView(button("BACK TO LIBRARY"){showHome()}); root.addView(scroll(c),LinearLayout.LayoutParams(-1,0,1f))
    }

    private fun contactCard(): View = MaterialCardView(this).apply{radius=dp(16).toFloat();setContentPadding(dp(14),dp(10),dp(14),dp(10));val c=column();c.addView(text("JOANZTECH ENTERPRISES",18f,navy,true));c.addView(text("Cashless Payment Till: 4615592"));c.addView(text("Contact: 0753006051"));c.addView(text("Email: joanztechenterprises@gmail.com"));c.addView(button("CALL JOANZTECH"){try{startActivity(Intent(Intent.ACTION_DIAL,Uri.parse("tel:0753006051")))}catch(_:Exception){}});addView(c)}

    private fun toast(message:String){Toast.makeText(this,message,Toast.LENGTH_LONG).show()}
    private fun space(h:Int)=Space(this).apply{layoutParams=LinearLayout.LayoutParams(1,dp(h))}
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
}
