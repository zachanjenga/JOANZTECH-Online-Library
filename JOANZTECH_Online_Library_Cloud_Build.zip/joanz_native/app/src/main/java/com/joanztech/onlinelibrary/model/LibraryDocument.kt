package com.joanztech.onlinelibrary.model

data class LibraryDocument(
    val title: String,
    val category: String,
    val description: String,
    val pdfUrl: String = "",
    val isPremium: Boolean = true
)
