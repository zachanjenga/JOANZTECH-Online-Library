package com.joanztech.onlinelibrary.data

import com.joanztech.onlinelibrary.model.LibraryDocument

object LibraryRepository {
    val categories = listOf(
        "ICT Notes & Past Papers",
        "Business Courses Notes & Past Papers",
        "Agriculture Notes & Past Papers",
        "Engineering Notes & Past Papers",
        "Building & Construction Notes & Past Papers",
        "Defensive Driving Notes & Past Papers",
        "Micro Teaching Notes",
        "Lesson Plan & Scheme of Work"
    )

    private val samples = listOf(
        LibraryDocument("ICT Technician Notes", categories[0], "Learning notes and revision resources for ICT students."),
        LibraryDocument("ICT Past Papers", categories[0], "ICT examination revision and practice papers."),
        LibraryDocument("Business Management Notes", categories[1], "Business course study materials."),
        LibraryDocument("Agriculture Notes", categories[2], "Agriculture learning and revision notes."),
        LibraryDocument("Engineering Revision Pack", categories[3], "Engineering notes and revision resources."),
        LibraryDocument("Building & Construction Notes", categories[4], "Building and construction study materials."),
        LibraryDocument("Defensive Driving Notes", categories[5], "Defensive driving learning and revision notes."),
        LibraryDocument("Micro Teaching Notes", categories[6], "Micro teaching preparation materials."),
        LibraryDocument("Lesson Plan & Scheme of Work", categories[7], "Templates and guidance for lesson planning and schemes of work.")
    )

    fun all(): List<LibraryDocument> = samples
}
