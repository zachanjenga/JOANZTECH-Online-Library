const axios = require('axios');
const {initializeApp} = require('firebase-admin/app');
const {getFirestore, FieldValue, Timestamp} = require('firebase-admin/firestore');
const {onCall, onRequest, HttpsError} = require('firebase-functions/v2/https');
const {defineSecret, defineString} = require('firebase-functions/params');

initializeApp();
const db = getFirestore();

const MPESA_CONSUMER_KEY = defineSecret('MPESA_CONSUMER_KEY');
const MPESA_CONSUMER_SECRET = defineSecret('MPESA_CONSUMER_SECRET');
const MPESA_PASSKEY = defineSecret('MPESA_PASSKEY');
const MPESA_SHORTCODE = defineString('MPESA_SHORTCODE', {default: '4615592'});
const MPESA_CALLBACK_URL = defineString('MPESA_CALLBACK_URL');

function normalizePhone(phone) {
  let value = String(phone || '').replace(/\\s+/g, '');
  if (value.startsWith('+')) value = value.substring(1);
  if (value.startsWith('0')) value = '254' + value.substring(1);
  return value;
}

async function getAccessToken() {
  const credentials = Buffer.from(
    `${MPESA_CONSUMER_KEY.value()}:${MPESA_CONSUMER_SECRET.value()}`
  ).toString('base64');

  const response = await axios.get(
    'https://api.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials',
    {
      headers: {Authorization: `Basic ${credentials}`},
      timeout: 15000,
    }
  );

  return response.data.access_token;
}

function timestamp() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  return d.getFullYear().toString() +
    pad(d.getMonth() + 1) +
    pad(d.getDate()) +
    pad(d.getHours()) +
    pad(d.getMinutes()) +
    pad(d.getSeconds());
}

exports.requestSubscriptionPayment = onCall(
  {
    region: 'africa-south1',
    secrets: [
      MPESA_CONSUMER_KEY,
      MPESA_CONSUMER_SECRET,
      MPESA_PASSKEY,
    ],
  },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError('unauthenticated', 'Please log in first.');
    }

    const phone = normalizePhone(request.data?.phone);
    const amount = Number(request.data?.amount || 500);

    if (!/^2547\\d{8}$/.test(phone)) {
      throw new HttpsError('invalid-argument', 'Use a valid Kenyan M-Pesa number.');
    }

    if (amount !== 500) {
      throw new HttpsError('invalid-argument', 'The current yearly subscription is KSh 500.');
    }

    const token = await getAccessToken();
    const ts = timestamp();
    const shortcode = MPESA_SHORTCODE.value();
    const password = Buffer.from(
      `${shortcode}${MPESA_PASSKEY.value()}${ts}`
    ).toString('base64');

    const response = await axios.post(
      'https://api.safaricom.co.ke/mpesa/stkpush/v1/processrequest',
      {
        BusinessShortCode: shortcode,
        Password: password,
        Timestamp: ts,
        TransactionType: 'CustomerPayBillOnline',
        Amount: amount,
        PartyA: phone,
        PartyB: shortcode,
        PhoneNumber: phone,
        CallBackURL: MPESA_CALLBACK_URL.value(),
        AccountReference: `JOANZTECH-${request.auth.uid.substring(0, 8)}`,
        TransactionDesc: 'JOANZTECH Online Library yearly subscription',
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        timeout: 20000,
      }
    );

    const checkoutRequestId = response.data.CheckoutRequestID;

    await db.collection('payments').doc(checkoutRequestId).set({
      userId: request.auth.uid,
      phone,
      amount,
      status: 'pending',
      merchantRequestId: response.data.MerchantRequestID || null,
      checkoutRequestId,
      createdAt: FieldValue.serverTimestamp(),
    });

    return {
      ok: true,
      message: 'M-Pesa prompt sent. Enter your M-Pesa PIN on your phone.',
      checkoutRequestId,
    };
  }
);

exports.mpesaCallback = onRequest(
  {region: 'africa-south1'},
  async (req, res) => {
    try {
      const body = req.body?.Body?.stkCallback;
      if (!body) {
        return res.status(400).json({ResultCode: 1, ResultDesc: 'Invalid callback'});
      }

      const checkoutRequestId = body.CheckoutRequestID;
      const paymentRef = db.collection('payments').doc(checkoutRequestId);
      const paymentSnap = await paymentRef.get();

      if (!paymentSnap.exists) {
        return res.status(404).json({ResultCode: 1, ResultDesc: 'Payment not found'});
      }

      const payment = paymentSnap.data();

      if (Number(body.ResultCode) === 0) {
        const expiry = new Date();
        expiry.setFullYear(expiry.getFullYear() + 1);

        await db.runTransaction(async (tx) => {
          tx.update(db.collection('users').doc(payment.userId), {
            subscriptionStatus: 'active',
            subscriptionExpiry: Timestamp.fromDate(expiry),
            updatedAt: FieldValue.serverTimestamp(),
          });

          tx.update(paymentRef, {
            status: 'paid',
            resultCode: 0,
            resultDescription: body.ResultDesc || 'Success',
            receipt: body.CallbackMetadata?.Item?.find(
              (item) => item.Name === 'MpesaReceiptNumber'
            )?.Value || null,
            completedAt: FieldValue.serverTimestamp(),
          });
        });
      } else {
        await paymentRef.update({
          status: 'failed',
          resultCode: Number(body.ResultCode),
          resultDescription: body.ResultDesc || 'Payment failed',
          completedAt: FieldValue.serverTimestamp(),
        });
      }

      return res.json({ResultCode: 0, ResultDesc: 'Accepted'});
    } catch (error) {
      console.error(error);
      return res.status(500).json({ResultCode: 1, ResultDesc: 'Server error'});
    }
  }
);
