# JOANZTECH Online Library — Cloud APK Build

This package is prepared for a cloud build using GitHub Actions. You do **not** need Android Studio or a PC with Android SDK installed on your side.

## What the workflow does

1. Downloads the project from the GitHub repository.
2. Installs Java 17.
3. Installs Android SDK Platform 35 and Build Tools 35.0.0.
4. Installs Gradle 8.13 in the cloud.
5. Builds the debug APK with `:app:assembleDebug`.
6. Uploads the APK as a workflow artifact named `JOANZTECH-Online-Library-Test-APK`.

The test build does **not** require M-Pesa Cloud Functions. The current app's test subscription button marks the subscription locally so you can test navigation and library access.

## Easiest method from an Android phone

### 1. Create a GitHub account
Open:
https://github.com/

Create a free account if you do not already have one.

### 2. Create a new repository
On GitHub:
- Tap **+** → **New repository**.
- Repository name: `JOANZTECH-Online-Library`
- Choose **Public** for the simplest free cloud build.
- Create the repository.

### 3. Upload this project
Extract this ZIP and upload the **contents of the `joanz_native` folder** to the repository root.

The repository root should contain:

- `app/`
- `.github/`
- `build.gradle.kts`
- `settings.gradle.kts`
- `gradle.properties`

Do not upload the outer `joanz_native` folder itself as an extra nesting level.

### 4. Start the cloud build
After uploading:
- Open the repository's **Actions** tab.
- Select **Build JOANZTECH Online Library APK**.
- Tap **Run workflow**.
- Select `main` and tap **Run workflow**.

The workflow builds the debug APK in GitHub's cloud. GitHub Actions can run Gradle builds on hosted runners, and Gradle's official setup action supports selecting a Gradle version directly. See the official Gradle/GitHub documentation:
https://docs.github.com/en/actions/tutorials/build-and-test-code/java-with-gradle

### 5. Download the APK
When the workflow shows a green check:
- Open the completed workflow run.
- Scroll to **Artifacts**.
- Download **JOANZTECH-Online-Library-Test-APK**.
- Extract the downloaded artifact.
- You will find the APK inside.

### 6. Install on your Android phone
Transfer/open the APK on your phone and install it. Android may ask you to allow installation from the browser/file manager for that APK source.

## Test payment mode

The test application displays:

- Yearly subscription: **KSh 500**
- M-Pesa Till: **4615592**
- Contact: **0753006051**
- Email: **joanztechenterprises@gmail.com**

For testing, tapping **I HAVE PAID** activates the subscription locally. It does not charge M-Pesa and does not contact the M-Pesa API.

## Production version later

When testing is complete, the subscription screen can be connected to your secure M-Pesa backend/Cloud Function. M-Pesa credentials should never be placed directly in the Android APK.

## Build configuration

- Application ID: `com.joanztech.onlinelibrary`
- Compile SDK: 35
- Target SDK: 35
- Minimum SDK: 23
- Java: 17
- Gradle: 8.13
- Android Gradle Plugin: 8.13.2
- Kotlin: 2.2.20

The cloud workflow intentionally builds a **debug APK for testing**, not a Play Store release. Android's official documentation distinguishes debug builds used for testing from signed release builds used for distribution.
